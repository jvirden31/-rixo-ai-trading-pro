# RIXO AI Trading V1 — mobile-first prototype

This is an educational **simulation-only** prototype for the RIXO AI Trading dashboard. It combines a simple brokerage-style summary with a chart preview and simulated scanner signals.

## Safety and limitations
- All chart and signal prices are synthetic demonstration data, not live market data.
- The signal rules are simple moving-average/momentum examples, not an AI model and not investment advice.
- Approving a signal records a simulation decision only. No broker is connected and no real orders can be placed.
- No Robinhood credentials or API keys are needed or should be entered.
- Risk calculations are planning estimates; real losses can exceed intended limits.

## Run in a cloud Python workspace
1. Upload the project files to a Python web workspace.
2. Install dependencies from `requirements.txt`.
3. Run: `uvicorn app:app --host 0.0.0.0 --port 8000`
4. Open the workspace's web preview.

Dependencies: FastAPI, Uvicorn, Pydantic. Decisions are stored in a local SQLite database (`trades.db`).

## Included
- `app.py` — FastAPI endpoints for demo signals, risk calculations, and simulation decisions.
- `index.html` — responsive mobile dashboard, demo chart, scanner cards, and decision history.
- `requirements.txt` — Python dependencies.

Live market data, real AI analysis, authentication, secure hosting, and brokerage integrations are not implemented. Add and test these separately before considering any live trading workflow.
