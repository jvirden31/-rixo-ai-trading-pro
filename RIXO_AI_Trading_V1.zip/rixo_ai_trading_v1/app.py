"""RIXO AI Trading V1: educational simulated-signal dashboard. No broker access."""
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from pathlib import Path
from datetime import datetime, timezone
import sqlite3

app = FastAPI(title='RIXO AI Trading V1')
DB = Path(__file__).with_name('trades.db')
ASSETS = [
    {'symbol':'SPY','market':'Stocks','style':'Day','closes':[100,100.2,100.1,100.4,100.7,100.5,100.8,101.1,101.3,101.2,101.5,101.7]},
    {'symbol':'BTC/USD','market':'Crypto','style':'Swing','closes':[100,99.9,100.1,100.4,100.2,100.5,100.7,100.9,101.0,101.2,101.4,101.6]},
    {'symbol':'EUR/USD','market':'Forex','style':'Day','closes':[100,100.3,100.2,100.1,99.9,100.0,99.8,99.7,99.5,99.6,99.4,99.2]},
    {'symbol':'QQQ','market':'Stocks','style':'Scalp','closes':[100,100.1,100.0,100.2,100.1,100.3,100.5,100.4,100.7,100.9,101.0,101.1]},
]
# Synthetic normalized price series, NOT live prices. This app never submits real orders.
def db():
    conn=sqlite3.connect(DB)
    conn.execute('CREATE TABLE IF NOT EXISTS decisions (id INTEGER PRIMARY KEY, timestamp TEXT, symbol TEXT, market TEXT, style TEXT, action TEXT, rationale TEXT)')
    return conn

def signal(a):
    p=a['closes']; fast=sum(p[-3:])/3; slow=sum(p[-8:])/8
    change=(p[-1]/p[-5]-1)*100
    direction='WATCH LONG' if fast>slow and change>0.3 else ('WATCH SHORT' if fast<slow and change<-.3 else 'NO TRADE')
    why=f'3-period SMA {fast:.2f} vs 8-period SMA {slow:.2f}; 4-period momentum {change:+.2f}%.'
    return {'symbol':a['symbol'],'market':a['market'],'style':a['style'],'signal':direction,'reason':why,'source':'DEMO synthetic normalized prices; not a live quote','tradable':False}

class Decision(BaseModel):
    symbol:str
    action:str

@app.get('/', response_class=HTMLResponse)
def home():
    return Path(__file__).with_name('index.html').read_text(encoding='utf-8')

@app.get('/api/signals')
def signals():
    return {'mode':'DEMO ONLY','broker_connected':False,'live_orders_enabled':False,'signals':[signal(a) for a in ASSETS]}

@app.get('/api/risk')
def risk(balance:float=300, risk_percent:float=.5, daily_loss_percent:float=1):
    if not 100<=balance<=500: raise HTTPException(400,'Demo balance must be between $100 and $500')
    if not 0<risk_percent<=1 or not 0<daily_loss_percent<=2: raise HTTPException(400,'Risk parameters outside demo limits')
    return {'balance':round(balance,2),'per_trade':round(balance*risk_percent/100,2),'daily_loss_limit':round(balance*daily_loss_percent/100,2),'note':'Planned risk only; fills, gaps and fees can exceed limits.'}

@app.post('/api/decisions')
def decisions(d:Decision):
    if d.action not in ('approve_simulation','reject'): raise HTTPException(400,'Invalid action')
    found=next((a for a in ASSETS if a['symbol']==d.symbol),None)
    if not found: raise HTTPException(404,'Unknown symbol')
    s=signal(found)
    if s['signal']=='NO TRADE' and d.action=='approve_simulation': raise HTTPException(400,'No qualifying demo signal')
    with db() as c:
        c.execute('INSERT INTO decisions(timestamp,symbol,market,style,action,rationale) VALUES(?,?,?,?,?,?)',(datetime.now(timezone.utc).isoformat(),found['symbol'],found['market'],found['style'],d.action,s['reason']))
    return {'saved':True,'simulated_only':True,'broker_order_sent':False}

@app.get('/api/decisions')
def history():
    with db() as c:
        rows=c.execute('SELECT timestamp,symbol,market,style,action FROM decisions ORDER BY id DESC LIMIT 30').fetchall()
    return [{'time':r[0],'symbol':r[1],'market':r[2],'style':r[3],'action':r[4]} for r in rows]
